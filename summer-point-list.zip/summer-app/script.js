/* ============================================================
   SUMMER POINT LIST — script.js
   Multi-device sync via Firebase Realtime Database (free tier).

   SETUP (one-time, 2 minuten):
   1. Ga naar https://console.firebase.google.com
   2. Maak een nieuw project aan (gratis)
   3. Klik "Realtime Database" → "Create database" → start in test mode
   4. Kopieer de database URL (ziet eruit als https://JOUWPROJECT-default-rtdb.firebaseio.com)
   5. Plak die URL hieronder bij FIREBASE_URL
   ============================================================ */

const FIREBASE_URL = "PLAK_HIER_JOUW_FIREBASE_URL";
// Voorbeeld: "https://summer-points-abc12-default-rtdb.firebaseio.com"

const DB_PATH = "/summerPointList.json";

/* ============================================================
   CHALLENGES
   ============================================================ */
const CHALLENGES = [
  { id:"c1",  pts:5,  text:"Wear a bikini",                          emoji:"👙" },
  { id:"c2",  pts:5,  text:"Ask for a stranger's snap",              emoji:"📱" },
  { id:"c3",  pts:5,  text:"Get called cute / pretty / sexy",        emoji:"💅" },
  { id:"c4",  pts:5,  text:"Selfie with a stranger",                 emoji:"🤳" },
  { id:"c5",  pts:10, text:"Ask for someone's number",               emoji:"📞" },
  { id:"c6",  pts:10, text:"Sleep outside",                          emoji:"🌙" },
  { id:"c7",  pts:10, text:"Tell someone they're cute",              emoji:"💬" },
  { id:"c8",  pts:20, text:"Set your friend up with someone",        emoji:"💕" },
  { id:"c9",  pts:20, text:"Kiss someone",                           emoji:"💋" },
  { id:"c10", pts:20, text:"Get day drunk",                          emoji:"🍹" },
  { id:"c11", pts:30, text:"Propose to a stranger",                  emoji:"💍" },
  { id:"c12", pts:30, text:"Get a guy's hoodie",                     emoji:"🧥" },
  { id:"c13", pts:30, text:"Truth or dare with a big unknown group", emoji:"🎲" },
  { id:"c14", pts:30, text:"Get your snap / number asked",           emoji:"🔥" },
];

const AVATARS = ["🌸","🦋","🌊","🌺","🍉","🌙","⭐","🦩","🌴","🐚","🍓","🌈"];
const POLL_MS = 4000;

/* ============================================================
   STATE
   ============================================================ */
let state       = { players: [], completions: {} };
let currentPlayer = null;
let pollTimer   = null;
let toastTimer  = null;

/* ============================================================
   FIREBASE HELPERS
   ============================================================ */
async function dbLoad() {
  try {
    const res = await fetch(FIREBASE_URL + DB_PATH);
    if (!res.ok) throw new Error("load failed");
    const data = await res.json();
    return data || { players: [], completions: {} };
  } catch (e) {
    console.warn("Firebase load error:", e);
    return state; // fall back to local copy
  }
}

async function dbSave(data) {
  try {
    await fetch(FIREBASE_URL + DB_PATH, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
  } catch (e) {
    console.warn("Firebase save error:", e);
  }
}

/* ============================================================
   HELPERS
   ============================================================ */
function getScore(playerId) {
  const done = state.completions[playerId] || [];
  return done.reduce((sum, id) => {
    const c = CHALLENGES.find(x => x.id === id);
    return sum + (c ? c.pts : 0);
  }, 0);
}

function getRanked() {
  return [...state.players]
    .map(p => ({ ...p, score: getScore(p.id), doneCount: (state.completions[p.id] || []).length }))
    .sort((a, b) => b.score - a.score);
}

function todayString() {
  return new Date().toLocaleDateString("nl-NL", { weekday:"long", day:"numeric", month:"long" });
}

/* ============================================================
   TOAST
   ============================================================ */
function showToast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}

/* ============================================================
   SCREEN SWITCHING
   ============================================================ */
function showScreen(name) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById("screen-" + name).classList.add("active");
}

/* ============================================================
   LOGIN SCREEN
   ============================================================ */
function renderLoginScreen() {
  const grid = document.getElementById("players-grid");
  grid.innerHTML = "";
  if (!state.players || state.players.length === 0) {
    grid.innerHTML = '<p class="empty-msg">Nog niemand. Wees de eerste! 🎉</p>';
    return;
  }
  state.players.forEach(p => {
    const pts = getScore(p.id);
    const btn = document.createElement("button");
    btn.className = "player-btn";
    btn.innerHTML = `
      <span class="p-avatar">${p.emoji}</span>
      <div class="p-name">${p.name}</div>
      <div class="p-score">${pts} pts</div>
    `;
    btn.addEventListener("click", () => loginAs(p));
    grid.appendChild(btn);
  });
}

function renderEmojiPicker() {
  const picker = document.getElementById("emoji-picker");
  picker.innerHTML = "";
  AVATARS.forEach((em, i) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = em;
    if (i === 0) btn.classList.add("selected");
    btn.addEventListener("click", () => {
      picker.querySelectorAll("button").forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
      document.getElementById("selected-emoji").value = em;
    });
    picker.appendChild(btn);
  });
}

/* ============================================================
   AUTH
   ============================================================ */
function loginAs(player) {
  currentPlayer = player;
  showScreen("app");
  renderApp();
  showToast(`Hey ${player.name}! ${player.emoji} Ready?`);
  startPolling();
}

async function addAndLogin() {
  const name  = document.getElementById("new-name").value.trim();
  const emoji = document.getElementById("selected-emoji").value;
  if (!name) { showToast("Vul eerst je naam in 😅"); return; }

  // Always load fresh before writing
  const fresh = await dbLoad();
  const existing = (fresh.players || []).find(p => p.name.toLowerCase() === name.toLowerCase());
  if (existing) { state = fresh; loginAs(existing); return; }

  const player = { id: "p" + Date.now(), name, emoji };
  if (!fresh.players) fresh.players = [];
  if (!fresh.completions) fresh.completions = {};
  fresh.players.push(player);
  fresh.completions[player.id] = [];

  await dbSave(fresh);
  state = fresh;
  loginAs(player);
}

function logout() {
  stopPolling();
  currentPlayer = null;
  showScreen("login");
  renderLoginScreen();
}

/* ============================================================
   POLLING
   ============================================================ */
function startPolling() {
  stopPolling();
  pollTimer = setInterval(async () => {
    setSyncing(true);
    const fresh = await dbLoad();
    state = fresh;
    if (currentPlayer) {
      // keep currentPlayer reference in sync
      currentPlayer = state.players.find(p => p.id === currentPlayer.id) || currentPlayer;
      renderWelcomeBar();
      const activeTab = document.querySelector(".nav-tab.active");
      if (activeTab) {
        const t = activeTab.dataset.tab;
        if (t === "scoreboard") renderScoreboard();
        if (t === "others")     renderOthers();
        // challenges: only re-render if not currently editing to avoid flicker
        if (t === "challenges") renderChallenges();
      }
      renderLoginScreen();
    }
    setSyncing(false);
  }, POLL_MS);
}

function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

function setSyncing(val) {
  const dot   = document.querySelector("#sync-status .sync-dot");
  const label = document.getElementById("sync-status");
  if (!dot) return;
  if (val) {
    dot.className = "sync-dot orange";
    label.innerHTML = '<span class="sync-dot orange"></span> Syncing…';
  } else {
    dot.className = "sync-dot green";
    label.innerHTML = '<span class="sync-dot green"></span> Live';
  }
}

/* ============================================================
   APP RENDER
   ============================================================ */
function renderApp() {
  renderWelcomeBar();
  renderChallenges();
  document.getElementById("score-date").textContent = todayString();
  switchTab("challenges");
}

function renderWelcomeBar() {
  const bar = document.getElementById("welcome-bar");
  const pts = getScore(currentPlayer.id);
  bar.innerHTML = `
    <div>
      <div class="welcome-greeting">Hey girl 👋</div>
      <div class="welcome-name">${currentPlayer.emoji} ${currentPlayer.name}</div>
    </div>
    <div class="score-badge">
      <div class="score-num">${pts}</div>
      <div class="score-lbl">punten</div>
    </div>
  `;
}

/* ── CHALLENGES ─────────────────────────────────────────── */
function renderChallenges(container = "tab-challenges", playerId = null, readonly = false) {
  const el   = document.getElementById(container);
  const pid  = playerId || currentPlayer.id;
  const done = state.completions[pid] || [];
  el.innerHTML = "";

  const groups = [
    { pts: 5,  icon: "🌺" },
    { pts: 10, icon: "🌊" },
    { pts: 20, icon: "🔥" },
    { pts: 30, icon: "💎" },
  ];

  groups.forEach(({ pts, icon }) => {
    const header = document.createElement("div");
    header.className = "section-header";
    header.innerHTML = `<span>${icon}</span> ${pts} punten <span class="pts-badge">${pts} pts</span>`;
    el.appendChild(header);

    CHALLENGES.filter(c => c.pts === pts).forEach(ch => {
      const isDone = done.includes(ch.id);
      const item = document.createElement("div");
      item.className = "challenge-item" + (isDone ? " done" : "") + (readonly ? " readonly" : "");
      item.innerHTML = `
        <div class="check-circle">${isDone ? "✓" : ""}</div>
        <span class="challenge-emoji">${ch.emoji}</span>
        <div class="challenge-name">${ch.text}</div>
        <div class="challenge-pts">+${ch.pts}</div>
      `;
      if (!readonly) item.addEventListener("click", () => toggleChallenge(ch.id));
      el.appendChild(item);
    });
  });
}

async function toggleChallenge(chId) {
  const fresh = await dbLoad();
  const done  = [...(fresh.completions[currentPlayer.id] || [])];
  const idx   = done.indexOf(chId);
  const ch    = CHALLENGES.find(c => c.id === chId);

  if (idx === -1) { done.push(chId);      showToast(`+${ch.pts} pts! ${ch.emoji} Yes!`); }
  else            { done.splice(idx, 1);  showToast(`${ch.text} uitgevinkt`); }

  fresh.completions[currentPlayer.id] = done;
  await dbSave(fresh);
  state = fresh;
  renderChallenges();
  renderWelcomeBar();
}

/* ── SCOREBOARD ─────────────────────────────────────────── */
function renderScoreboard() {
  const list   = document.getElementById("scoreboard-list");
  list.innerHTML = "";
  const ranked = getRanked();

  ranked.forEach((p, i) => {
    const isMe     = p.id === currentPlayer.id;
    const rankClass = i === 0 ? "rank-1" : i === 1 ? "rank-2" : i === 2 ? "rank-3" : "rank-other";
    const medal     = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`;

    const card = document.createElement("div");
    card.className = "score-card" + (isMe ? " is-me" : "");
    card.innerHTML = `
      <div class="rank-badge ${rankClass}">${medal}</div>
      <div class="score-avatar">${p.emoji}</div>
      <div class="score-name">${p.name}${isMe ? ' <span class="me-tag">(jij)</span>' : ""}</div>
      <div class="score-pts-wrap">
        <div class="score-pts-num">${p.score}</div>
        <div class="score-pts-lbl">punten</div>
      </div>
    `;
    list.appendChild(card);
  });
}

/* ── OTHERS ─────────────────────────────────────────────── */
function renderOthers() {
  const list   = document.getElementById("others-list");
  list.innerHTML = "";
  const others = state.players.filter(p => p.id !== currentPlayer.id);

  if (others.length === 0) {
    list.innerHTML = '<div class="no-others">Nog niemand anders toegevoegd 👀</div>';
    return;
  }

  others.forEach(p => {
    const pts  = getScore(p.id);
    const cnt  = (state.completions[p.id] || []).length;
    const card = document.createElement("div");
    card.className = "other-card";
    card.innerHTML = `
      <div class="other-avatar">${p.emoji}</div>
      <div class="other-info">
        <div class="other-name">${p.name}</div>
        <div class="other-done">${cnt} opdrachten gedaan</div>
      </div>
      <div class="other-pts">${pts} pts</div>
      <div class="other-arrow">›</div>
    `;
    card.addEventListener("click", () => viewPlayer(p));
    list.appendChild(card);
  });
}

function viewPlayer(player) {
  document.getElementById("view-player-title").textContent = `${player.emoji} ${player.name}`;
  renderChallenges("view-player-challenges", player.id, true);

  document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));
  document.getElementById("tab-view-player").classList.add("active");
}

/* ============================================================
   TAB SWITCHING
   ============================================================ */
function switchTab(name) {
  document.querySelectorAll(".nav-tab").forEach(t => t.classList.remove("active"));
  document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));

  document.querySelector(`.nav-tab[data-tab="${name}"]`).classList.add("active");
  document.getElementById("tab-" + name).classList.add("active");

  if (name === "scoreboard") renderScoreboard();
  if (name === "others")     renderOthers();
}

/* ============================================================
   INIT
   ============================================================ */
async function init() {
  // Check Firebase config
  if (FIREBASE_URL === "PLAK_HIER_JOUW_FIREBASE_URL") {
    document.body.innerHTML = `
      <div style="font-family:sans-serif;max-width:480px;margin:60px auto;padding:24px;background:#fff;border-radius:20px;box-shadow:0 4px 20px rgba(0,0,0,0.1);text-align:center">
        <div style="font-size:3rem;margin-bottom:16px">⚙️</div>
        <h2 style="color:#F4726B;margin-bottom:12px">Firebase instellen</h2>
        <p style="color:#666;margin-bottom:20px;line-height:1.6">
          Om de app multi-device te laten werken moet je een gratis Firebase project aanmaken.
        </p>
        <ol style="text-align:left;color:#555;line-height:2;padding-left:20px">
          <li>Ga naar <a href="https://console.firebase.google.com" target="_blank" style="color:#F4726B">console.firebase.google.com</a></li>
          <li>Maak een nieuw project aan (gratis)</li>
          <li>Klik "Realtime Database" → "Create database"</li>
          <li>Kies "Start in test mode" → Done</li>
          <li>Kopieer de database URL</li>
          <li>Plak de URL in <code style="background:#FFF0E6;padding:2px 6px;border-radius:4px">script.js</code> bij <code style="background:#FFF0E6;padding:2px 6px;border-radius:4px">FIREBASE_URL</code></li>
        </ol>
      </div>
    `;
    return;
  }

  // Load data
  const fresh = await dbLoad();
  state = fresh;

  renderEmojiPicker();
  renderLoginScreen();

  // Wiring
  document.getElementById("btn-add-login").addEventListener("click", addAndLogin);
  document.getElementById("new-name").addEventListener("keydown", e => { if (e.key === "Enter") addAndLogin(); });
  document.getElementById("btn-logout").addEventListener("click", logout);
  document.getElementById("btn-back-others").addEventListener("click", () => switchTab("others"));

  document.querySelectorAll(".nav-tab").forEach(btn => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });
}

document.addEventListener("DOMContentLoaded", init);
